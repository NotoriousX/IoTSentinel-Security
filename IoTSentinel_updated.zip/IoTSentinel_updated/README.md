
# IoTSentinel

## Description
IoTSentinel is a Python-based tool that scans your network for IoT devices, checks them against known vulnerabilities (CVEs), and provides a visual representation of the findings.

## Installation

1. Clone the repository or download the zip file.
2. Navigate to the project directory.
3. Install the required dependencies:

```bash
pip install -r requirements.txt
```

## Usage

Run the tool with the following command:

```bash
python iot_sentinel.py
```

## Note
- Ensure you have the necessary permissions to scan the network.
- Use this tool responsibly and ethically.

